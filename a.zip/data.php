<?php
require_once 'conn.php';



session_start();//启动会话存储数据

//数据操作
switch ($_POST['submit']) {/*这里判断按钮是否有操作*/
    //分组统计功能
    case '班级统计':
//获取取下拉菜单id value传的 select的name
        $classID = $_POST['select'];
        $result = $mysqli->query("select * from xsb where 班级代号='$classID'");/*这里查找学生表里的班级代号字段*/
        if ($result) {
            if (mysqli_num_rows($result)) {
                $_SESSION['ClassSelect'] = $result->fetch_all();
                //如果成功把查询到的数据赋值给数组
                echo "<script>alert('查询成功');</script>";
            } else {
                echo "<script>alert('未查询到数据');</script>";
                /*这里是如果查询到数据就用javascript弹出提示*/
            }
        } else {//输出错误信息
            echo $mysqli->error;
            echo "<script>alert('查询失败');</script>";
        }
        header('refresh:0.1; url=index.php?thisPages=statistics');
        break;
    case '登录':/*这里是登录功能*/
        $username = $_POST['usernc'];//账号
        $password = $_POST['userpwd'];//密码
        /*这两个是在html页面表单的input标签传递过来的值*/
        if (($username == '') || ($password == '')) {
           /*如果没有填写登录信息正确，那么会弹出对应的提示*/
            echo "<script>alert('用户名或密码不能为空,请重新输入登录信息!')</script>";
        } else if (($username != 'wzkc') || ($password != '666666')) {
            echo "<script>alert('用户名或密码错误,请重新输入登录信息! ')</script>";
        } else if (($username == 'wzkc') && ($password == '666666')) {
            # 用户名和密码正确,存到Session
            $_SESSION['isLogin'] = 1;
            $_SESSION['username'] = $username;//用户名
            // 若勾选7天内自动登录,则将其保存到Cookie并设置保留7天
            if ($_POST['remember'] == "yes") {
                setcookie('email', $username, time() + 7 * 24 * 60 * 60);
                setcookie('code', md5($username . md5($password)), time() + 7 * 24 * 60 * 60);
            } else {
                setcookie('email', '', time() - 999);
                setcookie('code', '', time() - 999);
            }
            // 跳转到登录成功的首页
            echo "<script>alert(' $username 登录成功！')</script>";//显示用户名 并提示登录成功
        }
        header('refresh:0.1; url=index.php');
        break;
    case '添加'://添加学生信息
        $id = $_POST['考生号'];
        $name = $_POST['姓名'];
        $datatime = $_POST['出生日期'];
        $sex = $_POST['性别'];
        $class = $_POST['专业'];
        $classID = $_POST['班级代号'];
        $grade = $_POST['总成绩'];
        $add_student_sql = "INSERT INTO `xsb` VALUES ('$id','$name','$sex','$datatime','$class','$classID','$grade');";
        $result = $mysqli->query($add_student_sql);/*查询*/
        if ($result) {//数据表信息
            echo "<script>alert('添加成功');</script>";
        } else {//输出错误信息
            echo $mysqli->error;
        }
        header('refresh:0.1; url=index.php');/*跳转到首页*/
        break;
    case '查询'://简单查询 条件定位考生号
        $id = $_POST['考生号'];
        $result = $mysqli->query("select * from xsb where 考生号='$id'");
        $ans = $result->fetch_row();//把所有字段取出
        if ($ans) {//信息获取成功
            $_SESSION['KIDSelect'] = $ans;
            echo "<script>alert('查询成功');</script>";
        } else {
            echo "<script>alert('查询失败');</script>";
        }
        header('refresh:0.1; url=index.php?thisPages=Query');
        break;
    case '修改'://修改信息
        $id = $_POST['考生号'];
        $name = $_POST['姓名'];
        $datatime = $_POST['出生日期'];
        $sex = $_POST['性别'];
        $class = $_POST['专业'];
        $classID = $_POST['班级代号'];
        $grade = $_POST['总成绩'];
        $sql_update = "UPDATE xsb SET 考生号 = '$id' , 姓名 = '$name', 出生日期 = '$datatime', 性别 = '$sex', 专业 = '$class', 班级代号 = '$classID' , 总成绩 = '$grade' WHERE 考生号 = '$id'";//更新数据表数据
        $result = $mysqli->query($sql_update);
        if ($result) {//信息获取成功对其进行修改
            echo "<script>alert('修改成功');</script>";
        } else {//输出错误信息
            echo $mysqli->error;
        }
        header('refresh:0.1; url=index.php');/*跳转到首页*/
        break;
}
switch ($_GET['thisPages']) {
    //删除功能
    case 'delete':
        if (isset($_GET['deleteid'])) {//删除参数
            $Kid = $_GET['deleteid'];
            $result = $mysqli->query("delete from xsb where 考生号='$id'");
            if ($result) {
                /*删除成功*/
                echo "<script>alert('删除成功');</script>";
            } else {
                echo $mysqli->error;
            }
        }
        header('refresh:0.1; url=index.php');/*跳转首页*/
        break;
}
