<?php
header("Content-type: text/html; charset=utf-8"); //设置文件编码格式utf-8
//包含连接数据库文件
include_once("conn.php");
if(isset($_GET['delid'])){
	$delid=$_GET['delid'];//获得删除参数id
//连接数据库判断通过id删除学生表中信息记录数据，如果id为空
if(mysqli_query($conn,"delete from xsb where 考生号='$delid'")){
	//则执行弹出框该条学生信息记录删除成功，然后回到首页界面
  	echo "<script>alert('该条学生信息记录删除成功！');location='index.php';</script>";
}else{
	//否则执行弹出框该条学生信息记录删除失败，然后回到上个历史界面
  	echo "<script>alert('该条学生信息记录删除失败！');history.back();</script>";
}
}
?>