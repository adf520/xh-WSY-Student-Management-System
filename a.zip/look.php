<?php
include_once("islogin.php");
?>
<?php
include_once("conn.php");   //连接数据库
$pagesize=10;     //定义页面显示3条数据
$result=mysqli_query($conn,"SELECT COUNT(*) from xsb");    //执行查询数据库中所有的数据
$row=mysqli_fetch_row($result);     
$infocount=$row[0];     //获取总留言条数
$pagecount=ceil($infocount/$pagesize);    //用总留言条数/每页显示的数据来获取总页数
$currpage=isset($_GET["page"])?$_GET["page"]:1;    //定义当前访问的页数

if($currpage>$pagecount)    //判断外部参数是否超出了最大范围
{
$currpage=1;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
<style type="text/css">
.top {
    height: 150px;
    width: 960px;
    margin-right: auto;
    margin-left: auto;
    background-image: url(image/top.jpg);
    background-repeat: no-repeat;
}
.middle {
    width: 960px;
    margin-right: auto;
    margin-left: auto;
    height: 360px;
}
.bottom {
    height: 300px;
    width: 960px;
	background: url("image/bottom.jpg");
    margin-right: auto;
    margin-left: auto;
}
.menu {
    height: 35px;
    width: 960px;
    margin-right: auto;
    margin-left: auto;
    background-color: #9CCC65;
    border: 1px solid #FFFFFF;
}
	.menu_tb{
		
	}
a:link {
    text-decoration: none;
}
a:visited {
    text-decoration: none;
}
a:hover {
    text-decoration: none;
}
a:active {
    text-decoration: none;
}
.ziduan {
    height: 30px;
}
	.ziduan_tb{
    background-color: #E0E0E0;
    border: 0px none #FFFFFF;
	}
.stu_xinxi {
	height: 30px;
}
.fenye {
    border-top: 3px none #757575;
    border-right: 3px solid #757575;
    border-bottom: 3px solid #757575;
    border-left: 3px solid #757575;
}
	.tuichu{
		color: #FFFFFF;
	}
</style>
</head>

<body style="">
<div class="top">
  <table width="80" border="0" align="right" class="tuichu">
    <tbody>
      <tr>
        <td><a href="outlogin.php">退出登录</a></td>
      </tr>
    </tbody>
  </table>
</div>
<div class="menu">
  <table width="960" height="35" border="1" bordercolor="white" class="menu_tb" >
    <tbody>
      <tr>
        <td width="160" align="center">2020-6-10</td>
        <td width="160" align="center"><a href="look.php">浏览学生信息</a></td>
        <td width="160" align="center"><a href="add.php">添加学生信息</a></td>
        <td width="160" align="center"><a href="search_simple.php">简单查询</a></td>
        <td width="160" align="center"><a href="search_advanced.php">高级查询</a></td>
        <td width="160" align="center"><a href="search_group.php">分组统计查询</a></td>
      </tr>
    </tbody>
  </table>
</div>
<div class="middle">
  <div class="ziduan">
    <table width="960" height="30" border="1" cellspacing="0"  bordercolor="#BDBDBD" class="ziduan_tb" >
      <tbody>
        <tr>
          <td width="160" align="center">学生号</td>
          <td width="140" align="center">姓名</td>
          <td width="100" align="center">性别</td>
          <td width="200" align="center">专业</td>
          <td width="100" align="center">班级代号</td>
          <td width="100" align="center">总成绩</td>
          <td width="100" align="center">操作</td>
        </tr>
      </tbody>
    </table>
	  <?php
	  //执行数据库，获取留言数据[(当前页数-1)*每页显示的留言数]，进行分页处理       
	  $re=mysqli_query($conn,"select * from xsb limit ".($currpage-1)*$pagesize.",".$pagesize);  
	  while($row=mysqli_fetch_array($re)){
		  echo '<div class="stu_xinxi">
    <table width="960"  height="30" border="1"cellspacing="0" bordercolor="#BDBDBD">
      <tbody>
        <tr>
          <td width="160" align="center">'.$row["考生号"].'</td>
          <td width="140" align="center">'.$row["姓名"].'</td>
          <td width="100" align="center">'.$row["性别"].'</td>
          <td width="200" align="center">'.$row["专业"].'</td>
          <td width="100" align="center">'.$row["班级代号"].'</td>
          <td width="100" align="center">'.$row["总成绩"].'</td>
           <td width="100" align="center"><a href="del.php?id='.$row["考生号"].'">删除</a>/<a href="edit.php?ksh='.$row["考生号"].'">修改</a></td>
        </tr>            
      </tbody>
    </table>
  </div>';
	  }
		  
		  ?>
    <div class="fenye">
	  <table width="960" border="0" align="center">
  <tbody>
    <tr>
		<td width="290" align="left">共有<?php echo $infocount?>条记录 第<?php echo $currpage?>页/共<?php echo $pagecount?>页</td>
		
      <td width="75" align="center"><a href="?page=1">首页</a></td>    
      <!--通过插入超链接，将页码设成第一页，实现回到首页的功能-->
		<?php        //判断当前页是否小大于1，如果大于1才能进行上一页操作
		if($currpage>1){    
		?>                 
		              <!--执行上一页操作-->
		<td width="75" align="center"><a href="?page=<?php echo $currpage-1;?>">上一页</a></td>    
		<?php } ?>
		
      <td width="66" align="center"><?php for($i=1;$i<=$pagecount;$i++)          //通过循环，将页码依次输出
		{
			if($i==$currpage)    //判断当前页数是否为当前选择的页面
			{
				echo "<b>$i</b>&nbsp";      //如果是当前页数，则输出一个不用点击的链接
			}else{
			echo "<a href=?page=$i>$i</a>&nbsp;";    //如果不是当前链接，则输出分页符号，并创建超链接
			}    
		} ?></td>
		<?php           //判断当前页是否小于总页数，如果小于总页数才能进行下一页操作
		if($currpage<$pagecount){
	    ?>             
		                <!--执行下一页操作-->
	<td width="75" align="center"><a href="?page=<?php echo $currpage+1?>">下一页</a></td>
		<?php } ?>
		
      <td width="75" align="center"><a href="?page=<?php echo $pagecount;?>">尾页</a></td>   <!--通过插入超链接，将页码设成最后一页，实现跳到最后一页的功能-->
		<td width="274"></td>
    </tr>
  </tbody>
</table>
    </div>
  </div>
  
	
	
	
	
	
</div>
<div class="bottom"></div>
</body>
</html>
