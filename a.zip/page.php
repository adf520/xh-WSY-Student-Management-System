













<?php 

// 实现分页
// 第一步：每页显示10条
$pagesize=10;
// 第二步：当前在第几页
if(isset($_GET['page'])&&$_GET['page']>1)
{
	$page=$GET['page'];
}
else{
	$page=1;
}
// 第三步：获得总页数
$sql="select * from xsb";
$rs=mysqli_query($conn,$sql);
$records=mysql_num_rows($rs);//获取总页数
// 计算现实的总页数=向上取整（总条记录数/某页现实的条数）
$pagecount=ceil($records/$pagesize);
// 第四步：开始读取数据
$start=($page-1)*$pagesize;
$sql="select * from xsb order by 考生号 asc limit $start,10";
$rs=mysqli_query($conn,$sql);
// 通过mysqli_fetch_assoc从结果中读取一行数据形成关联数组
// 记录指针移动到下一行
while ($row=mysqli_fetch_assoc($rs)) {
	// 若得到的数据为真，循环输出打印
	echo "<tr>";
	echo "<td>".$row['考生号'].'</td>';//考生号
	echo "<td>".$row['姓名'].'</td>';//姓名
	echo "<td>".$row['性别'].'</td>';//性别
	echo "<td>".$row['专业'].'</td>';//专业
	echo "<td>".$row['班级代号'].'</td>';//班级代号
	echo "<td>".$row['总成绩'].'</td>';//总成绩
	echo "<td>"."操作";'</td>';//操作
    echo'</tr>';
	
}
 ?>
</tbody>
</table>

<!-- 实现翻页功能 -->
<div id="span">
	<span>总共有 <?php echo "$pagecount"; ?>页，当前在第<?php echo $page ?>页</span>

    <!-- 首页直接返回到第一页 -->
    <?php
    // 通过循环，将页面输出
    for ($i=1; $i<=$pagecount ; $i++) { 
    	 echo "<span><a href=?page=$i>$i</a></span>";
    	# code...
    }
    mysqli_free_result($rs);
    ?>
	    <!-- 尾页，直接通过PHP所得数据返回最后一页 -->
	    <span><a href="?page=<?php echo $pagecount;?>">尾页</a></span>
   
	</div>
